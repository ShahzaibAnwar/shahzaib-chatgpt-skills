# Frontend Design Patterns

Use this file when the request is vague and a fast product decision is needed.

## Pick a direction based on the product

### SaaS / B2B tools
- Prioritize clarity, trust, and information hierarchy.
- Use restrained color, precise spacing, and strong table or card structure.
- Good defaults: sharp typography, muted surfaces, clear primary actions.

### Creative portfolio / agency
- Prioritize composition, motion, and identity.
- Use bolder type, stronger contrast, asymmetric layout, and visual storytelling.
- Let fewer sections carry more personality.

### Ecommerce / product showcase
- Prioritize image hierarchy, pricing clarity, and conversion flow.
- Make product cards, filters, testimonials, and checkout actions easy to scan.

### Internal dashboard
- Prioritize density with control.
- Use compact but readable tables, filters, stat blocks, and contextual actions.
- Keep interaction states obvious and reduce decorative noise.

## Common page structures

### Landing page
1. Hero with clear value proposition and primary action
2. Proof or trust section
3. Feature blocks with differentiated layouts
4. Social proof or case study
5. Pricing or conversion section
6. Strong final call to action

### Dashboard screen
1. Header with title and scoped actions
2. Top-line KPI strip
3. Main chart or primary workflow area
4. Supporting tables, breakdowns, or side panels
5. Filters and export or drill-down actions

### Form-driven screen
1. Clear heading and short explanatory text
2. Grouped inputs with labels and validation cues
3. Secondary help text only where needed
4. Strong submit area with visible state changes

## Visual refinement checklist

- Strengthen the first screen before styling lower sections.
- Make spacing differences meaningful, not random.
- Ensure at least one memorable visual move: composition, type treatment, surface treatment, or motion pattern.
- Remove anything that feels like filler.
- Keep calls to action obvious without making every element loud.
