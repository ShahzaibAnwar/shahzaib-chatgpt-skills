---
name: frontend-developer
description: build polished frontend interfaces and production-ready ui code for react, next.js, html, css, tailwind, and lightweight javascript tasks. use when chatgpt is asked to create or improve landing pages, dashboards, components, app screens, design systems, responsive layouts, ui refactors, accessibility polish, or visual redesigns. trigger this skill for requests that involve frontend implementation plus design judgment, especially when the user wants something that feels premium, distinctive, github-ready, or more refined than generic boilerplate.
---

# Frontend Developer

Build working frontend code with strong product taste. Deliver interfaces that are visually intentional, responsive, accessible, and ready for real-world iteration rather than generic demo output.

## Working style

1. Identify the product context before coding.
   - Infer the audience, primary action, and device priorities from the user's prompt.
   - Decide whether the task is best served by a component, full page, multi-section landing page, dashboard screen, or small app shell.

2. Choose one clear aesthetic direction.
   - Commit to a design point of view instead of mixing styles.
   - Favor memorable choices in typography, spacing, composition, contrast, and motion.
   - Avoid default-looking layouts, weak hierarchy, and overused "ai app" styling.

3. Implement production-grade code.
   - Make the result functional and easy to extend.
   - Prefer clean structure, reusable sections, consistent tokens, and semantic markup.
   - Keep the code runnable with minimal setup.

4. Verify quality before finishing.
   - Check responsiveness across mobile and desktop.
   - Check visual hierarchy, accessibility basics, and obvious interaction gaps.
   - Tighten copy, spacing, states, and alignment before presenting the result.

## Output decision rules

### For React or Next.js requests
- Return a single production-ready component or page unless the user explicitly asks for multiple files.
- Use composable sections and clearly named constants for repeated content.
- Prefer Tailwind utility classes when the environment supports them.
- Use tasteful motion only when it improves the experience.

### For plain HTML/CSS/JS requests
- Return a complete, runnable file when possible.
- Keep JavaScript lightweight and purposeful.
- Prefer CSS variables for theme tokens and reusable spacing or color decisions.

### For redesign or polish requests
- Preserve the user's functional intent.
- Improve hierarchy, spacing, typography, states, and responsiveness first.
- Remove clutter before adding decoration.

## Design standards

### Layout
- Create strong section rhythm.
- Use asymmetry, contrast, grouping, or negative space intentionally.
- Avoid flat, repetitive card grids unless the content truly requires them.

### Typography
- Create a visible difference between headline, subhead, body, and metadata.
- Use concise, product-appropriate copy.
- Prefer tighter, more confident headings over vague marketing filler.

### Color and surfaces
- Use a restrained palette with one or two purposeful accents.
- Build depth through layering, borders, shadows, blur, texture, or contrast where appropriate.
- Do not default to purple-on-white saas gradients unless the user specifically wants that style.

### Interaction
- Include hover, focus, active, and disabled states when relevant.
- Make buttons, inputs, nav, and cards feel deliberate.
- Use animation sparingly and consistently.

### Responsiveness
- Design mobile-first unless the prompt clearly prioritizes desktop.
- Prevent broken wrapping, cramped padding, and unusable tap targets.
- Ensure important calls to action stay obvious on smaller screens.

### Accessibility
- Use semantic html.
- Preserve adequate contrast.
- Add labels, alt text, and aria attributes where they materially help.
- Never communicate critical meaning by color alone.

## Code quality rules

- Keep naming readable and specific.
- Avoid unnecessary dependencies.
- Avoid placeholder comments like "add more styling here" in final output.
- Do not leave obvious dead code, unused imports, or fake data structures unless they help demonstrate a realistic pattern.
- When inventing sample content, make it believable and aligned to the product context.

## What to avoid

- Generic hero sections with stock startup copy.
- Overcrowded dashboards with no hierarchy.
- Repetitive spacing scales that make every block feel the same.
- Decorative effects that hurt readability.
- Fancy code patterns that make editing harder without adding user value.

## Response format

When delivering the result:

1. Start with a one-paragraph summary of the design direction and what was built.
2. Provide the code.
3. If useful, add 3 to 6 concise notes covering responsiveness, customization points, or implementation details.

## Examples of requests that should trigger this skill

- Create a premium saas landing page in react and tailwind.
- Build a clean admin dashboard screen for order analytics.
- Redesign this signup form so it feels modern and trustworthy.
- Make this html page look like a real product instead of a template.
- Build a reusable pricing section with monthly and yearly toggle.
- Improve the frontend for this portfolio and make it github-ready.

## Extra guidance

When the prompt is underspecified, make grounded product decisions instead of stalling. Choose a coherent visual direction, implement the most likely useful structure, and keep the result easy to adapt.
